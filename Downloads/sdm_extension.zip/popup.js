// ── SwedecrafT SDM – Popup ────────────────────────────────────────────────────

const pill           = document.getElementById('pill');
const dot            = document.getElementById('dot');
const statusText     = document.getElementById('statusText');
const interceptToggle= document.getElementById('interceptToggle');
const urlInput       = document.getElementById('urlInput');
const sendBtn        = document.getElementById('sendBtn');
const feedback       = document.getElementById('feedback');
const refreshBtn     = document.getElementById('refreshBtn');
const interceptStatus= document.getElementById('interceptStatus');

// ── Hämta status från background ─────────────────────────────────────────────
function refreshStatus() {
  chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (res) => {
    if (!res) return;
    setOnline(res.sdmOnline);
    interceptToggle.checked = res.interceptOn;
    interceptStatus.textContent = res.interceptOn ? 'Aktiv' : 'Pausad';
  });
}

function setOnline(online) {
  if (online) {
    pill.className      = 'pill online';
    dot.className       = 'dot online';
    statusText.textContent = 'SDM ansluten';
    sendBtn.disabled    = false;
  } else {
    pill.className      = 'pill offline';
    dot.className       = 'dot offline';
    statusText.textContent = 'SDM offline';
    sendBtn.disabled    = true;
  }
}

// ── Toggle: auto-fångst ───────────────────────────────────────────────────────
interceptToggle.addEventListener('change', () => {
  const val = interceptToggle.checked;
  chrome.runtime.sendMessage({ type: 'SET_INTERCEPT', value: val });
  interceptStatus.textContent = val ? 'Aktiv' : 'Pausad';
});

// ── Uppdatera-knapp ───────────────────────────────────────────────────────────
refreshBtn.addEventListener('click', () => {
  refreshBtn.style.transform = 'rotate(360deg)';
  refreshBtn.style.transition = 'transform 0.4s';
  setTimeout(() => {
    refreshBtn.style.transform = '';
    refreshBtn.style.transition = '';
  }, 400);
  chrome.runtime.sendMessage({ type: 'PING' }, (res) => {
    setOnline(res?.sdmOnline ?? false);
  });
});

// ── Manuell URL ───────────────────────────────────────────────────────────────
urlInput.addEventListener('input', () => {
  const v = urlInput.value.trim();
  sendBtn.disabled = !(v.startsWith('http://') || v.startsWith('https://'));
  feedback.textContent = '';
  feedback.className   = 'feedback';
});

urlInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !sendBtn.disabled) sendBtn.click();
});

sendBtn.addEventListener('click', () => {
  const url = urlInput.value.trim();
  if (!url) return;

  const filename = url.split('/').pop().split('?')[0] || 'fil';
  sendBtn.disabled     = true;
  feedback.textContent = 'Skickar...';
  feedback.className   = 'feedback';

  chrome.runtime.sendMessage(
    { type: 'SEND_URL', url, filename },
    (res) => {
      if (res?.ok) {
        feedback.textContent = '✓ Nedladdning startad i SDM!';
        feedback.className   = 'feedback ok';
        urlInput.value       = '';
        setTimeout(() => {
          feedback.textContent = '';
          feedback.className   = 'feedback';
        }, 3000);
      } else {
        feedback.textContent = '✗ Kunde inte nå SDM. Är programmet igång?';
        feedback.className   = 'feedback err';
      }
      sendBtn.disabled = false;
    }
  );
});

// ── Starta ───────────────────────────────────────────────────────────────────
refreshStatus();
