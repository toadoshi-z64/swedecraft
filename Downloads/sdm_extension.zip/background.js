// ── SwedecrafT SDM – Background Service Worker ────────────────────────────────
const SDM_PORT    = 6660;
const SDM_URL     = `http://localhost:${SDM_PORT}/download`;
const PING_URL    = `http://localhost:${SDM_PORT}/ping`;
const CHECK_MS    = 8000;   // Kontrollera SDM-status var 8:e sekund

// Filändelser som alltid ska fångas av SDM (ej text/bilder)
const INTERCEPT_EXTENSIONS = new Set([
  'zip','rar','7z','tar','gz','bz2','xz','zst',
  'exe','msi','dmg','deb','rpm','pkg','appimage',
  'mp4','mkv','avi','mov','wmv','m4v','webm','flv',
  'mp3','wav','flac','aac','ogg','m4a','opus',
  'iso','img','bin','apk','ipa',
  'pdf','docx','xlsx','pptx',
  'torrent',
]);

let sdmOnline   = false;
let interceptOn = true;   // Kan stängas av via popup

// ── Läs inställningar ─────────────────────────────────────────────────────────
async function loadSettings() {
  const s = await chrome.storage.local.get({ intercept: true });
  interceptOn = s.intercept;
}

// ── Pingkontroll mot SDM ──────────────────────────────────────────────────────
async function pingSDM() {
  try {
    const r = await fetch(PING_URL, { method: 'GET' });
    sdmOnline = r.ok;
  } catch {
    sdmOnline = false;
  }
  // Uppdatera badge
  chrome.action.setBadgeText({ text: sdmOnline ? '' : '!' });
  chrome.action.setBadgeBackgroundColor({ color: sdmOnline ? '#2288e0' : '#cc4444' });
}

// Starta pingloop
pingSDM();
setInterval(pingSDM, CHECK_MS);

// ── Skicka URL till SDM ───────────────────────────────────────────────────────
async function sendToSDM(url, filename) {
  try {
    const resp = await fetch(SDM_URL, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ url, filename }),
    });
    return resp.ok;
  } catch {
    return false;
  }
}

// ── Avgör om en URL ska fångas ────────────────────────────────────────────────
function shouldIntercept(url, filename) {
  if (!interceptOn || !sdmOnline) return false;

  // Kolla filändelse i URL eller filnamn
  const check = (filename || url).split('?')[0].toLowerCase();
  const ext   = check.split('.').pop();
  return INTERCEPT_EXTENSIONS.has(ext);
}

// ── Lyssna på nya nedladdningar ───────────────────────────────────────────────
chrome.downloads.onCreated.addListener(async (item) => {
  await loadSettings();

  if (!shouldIntercept(item.url, item.filename)) return;

  // Avbryt Chrome-nedladdningen
  chrome.downloads.cancel(item.id, async () => {
    chrome.downloads.erase({ id: item.id });

    const filename = item.filename
      ? item.filename.split(/[\\/]/).pop()
      : item.url.split('/').pop().split('?')[0] || 'fil';

    const ok = await sendToSDM(item.url, filename);

    if (ok) {
      chrome.notifications.create({
        type:    'basic',
        iconUrl: 'icons/icon48.png',
        title:   'SDM – Nedladdning startad',
        message: `"${filename}" skickas till SwedecrafT Download Manager.`,
      });
    } else {
      // SDM offline eller fel — låt Chrome ladda ned istället
      chrome.downloads.download({ url: item.url, filename });
      chrome.notifications.create({
        type:    'basic',
        iconUrl: 'icons/icon48.png',
        title:   'SDM – Ej ansluten',
        message: 'SDM körs inte. Filen laddas ned av Chrome istället.',
      });
    }
  });
});

// ── Exponera status till popup ────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg.type === 'GET_STATUS') {
    reply({ sdmOnline, interceptOn });
  }
  if (msg.type === 'SET_INTERCEPT') {
    interceptOn = msg.value;
    chrome.storage.local.set({ intercept: msg.value });
    reply({ ok: true });
  }
  if (msg.type === 'SEND_URL') {
    sendToSDM(msg.url, msg.filename).then(ok => reply({ ok }));
    return true; // async reply
  }
  if (msg.type === 'PING') {
    pingSDM().then(() => reply({ sdmOnline }));
    return true;
  }
});
