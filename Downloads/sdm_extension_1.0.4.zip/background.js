// SwedecrafT SDM – Background Service Worker v4
const SDM_PORT = 6660;
const SDM_URL  = `http://localhost:${SDM_PORT}/download`;
const PING_URL = `http://localhost:${SDM_PORT}/ping`;

// ── Filändelser ───────────────────────────────────────────────────────────────
const INTERCEPT_EXT = new Set([
  'zip','rar','7z','tar','gz','bz2','xz','zst','lz4',
  'exe','msi','dmg','deb','rpm','pkg','appimage',
  'mp4','mkv','avi','mov','wmv','m4v','webm','flv','ts',
  'mp3','wav','flac','aac','ogg','m4a','opus','wma',
  'iso','img','bin','nrg','apk','ipa','xapk',
  'pdf','epub','mobi','torrent',
]);

// ── Domäner – intercepta ALLTID (oavsett extension) ──────────────────────────
const ALWAYS_DOMAINS = [
  'buzzheavier.com',
  'gofile.io','store1.gofile.io','store2.gofile.io','store3.gofile.io',
  'store4.gofile.io','store5.gofile.io','store6.gofile.io',
  'cdn01.gofile.io','cdn02.gofile.io','cdn03.gofile.io',
  'fileditch.com','pixeldrain.com','1fichier.com',
  'rapidgator.net','transfer.sh','filebin.net',
];

function hostOf(url) {
  try { return new URL(url).hostname.replace(/^www\./, ''); } catch { return ''; }
}

function isAlwaysDomain(url) {
  const h = hostOf(url);
  return ALWAYS_DOMAINS.some(d => h === d || h.endsWith('.'+d));
}

function hasBinaryExt(url, filename) {
  const s = (filename || url).split('?')[0].toLowerCase();
  return INTERCEPT_EXT.has(s.split('.').pop());
}

// ── Pinga SDM ─────────────────────────────────────────────────────────────────
async function checkSDM() {
  try {
    const r = await fetch(PING_URL, { signal: AbortSignal.timeout(2000) });
    return r.ok;
  } catch { return false; }
}

// ── Uppdatera badge ───────────────────────────────────────────────────────────
async function refreshBadge() {
  const online = await checkSDM();
  chrome.action.setBadgeText({ text: online ? '' : '!' });
  chrome.action.setBadgeBackgroundColor({ color: online ? '#2288e0' : '#cc4444' });
  return online;
}
refreshBadge();
setInterval(refreshBadge, 10000);

// ── Cookies för URL ───────────────────────────────────────────────────────────
async function cookieStr(url) {
  try {
    const list = await chrome.cookies.getAll({ url });
    return list.map(c => `${c.name}=${c.value}`).join('; ');
  } catch { return ''; }
}

// ── Skicka till SDM ───────────────────────────────────────────────────────────
async function sendToSDM(payload) {
  try {
    const r = await fetch(SDM_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return r.ok;
  } catch { return false; }
}

function notify(title, message) {
  chrome.notifications.create({
    type: 'basic', iconUrl: 'icons/icon48.png', title, message,
  });
}

// ── webRequest: fånga Content-Disposition: attachment ────────────────────────
const cdCache = new Map();

chrome.webRequest.onHeadersReceived.addListener(details => {
  const cd = details.responseHeaders
    ?.find(h => h.name.toLowerCase() === 'content-disposition')?.value ?? '';
  const ct = details.responseHeaders
    ?.find(h => h.name.toLowerCase() === 'content-type')?.value ?? '';

  if (cd.toLowerCase().includes('attachment') && !ct.toLowerCase().includes('text/html')) {
    let fn = '';
    let m = cd.match(/filename\*\s*=\s*(?:UTF-8'')?([^;\n]+)/i);
    if (m) fn = decodeURIComponent(m[1].trim().replace(/^"|"$/g,''));
    else {
      m = cd.match(/filename\s*=\s*"?([^";\n]+)"?/i);
      if (m) fn = m[1].trim();
    }
    cdCache.set(details.url, { fn, referrer: details.initiator || '' });
    setTimeout(() => cdCache.delete(details.url), 60000);
  }
}, { urls: ['<all_urls>'] }, ['responseHeaders']);

// ── Huvud-lyssnare: onDeterminingFilename ─────────────────────────────────────
// Detta event körs INNAN Chrome visar nedladdningsdialogen eller fältet.
// Genom att hålla suggest-callbacken öppen (aldrig anropa den) fryser vi
// Chromes nedladdning tyst medan vi skickar till SDM, och avbryter sedan.
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  handleDownload(item, suggest);
  return true; // = vi hanterar suggest asynkront
});

async function handleDownload(item, suggest) {
  const { intercept } = await chrome.storage.local.get({ intercept: true });
  if (!intercept) {
    suggest();
    return;
  }

  const cached = cdCache.get(item.url);

  const should = isAlwaysDomain(item.url)
              || hasBinaryExt(item.url, item.filename)
              || !!cached;
  if (!should) {
    suggest();
    return;
  }

  const online = await checkSDM();
  if (!online) {
    suggest(); // SDM offline – låt Chrome ladda ned normalt
    return;
  }

  // Avbryt Chrome-nedladdningen tyst – suggest anropas ALDRIG
  chrome.downloads.cancel(item.id, () => {
    chrome.downloads.erase({ id: item.id });
  });

  const filename = cached?.fn
    || (item.filename ? item.filename.split(/[/\\]/).pop() : '')
    || item.url.split('/').pop().split('?')[0]
    || 'fil';

  const cookies  = await cookieStr(item.url);
  const referrer = item.referrer || cached?.referrer || '';

  const ok = await sendToSDM({ url: item.url, filename, cookies, referrer });
  if (ok) {
    notify('SDM – Nedladdning startad', `"${filename}" skickas till SDM.`);
  } else {
    // Fallback: starta om Chrome-nedladdningen
    chrome.downloads.download({ url: item.url, filename });
    notify('SDM – Ej ansluten', 'SDM körs inte. Chrome laddar ned istället.');
  }
}

// ── Meddelanden från content scripts / popup ──────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg.type === 'GET_STATUS') {
    Promise.all([
      checkSDM(),
      chrome.storage.local.get({ intercept: true }),
    ]).then(([online, stored]) => {
      reply({ online, interceptOn: stored.intercept });
    });
    return true;
  }
  if (msg.type === 'SET_INTERCEPT') {
    chrome.storage.local.set({ intercept: msg.value });
    reply({ ok: true });
  }
  if (msg.type === 'PING') {
    refreshBadge().then(online => reply({ sdmOnline: online }));
    return true;
  }
  if (msg.type === 'SEND_URL') {
    const { url, filename, referrer, cookies, auth } = msg;
    sendToSDM({ url, filename: filename||'', referrer: referrer||'', cookies: cookies||'', auth: auth||'' })
      .then(ok => reply({ ok }));
    return true;
  }
  if (msg.type === 'CONTENT_DOWNLOAD') {
    const { url, filename, referrer, auth } = msg;
    cookieStr(url).then(async cookies => {
      const ok = await sendToSDM({ url, filename, referrer: referrer||'', cookies, auth: auth||'' });
      if (ok) notify('SDM – Nedladdning startad', `"${filename}" skickas till SDM.`);
      reply({ ok });
    });
    return true;
  }
});
