// SwedecrafT SDM – Content Script v3
// GoFile: interceptar API-svaret som innehåller CDN-URL + token
// BuzzHeavier: interceptar download-klick och window.open
(function () {
  'use strict';
  const host = location.hostname.replace(/^www\./, '');

  if (host === 'gofile.io' || host.endsWith('.gofile.io')) setupGoFile();
  if (host === 'buzzheavier.com' || host.endsWith('.buzzheavier.com')) setupBuzzHeavier();

  // ══════════════════════════════════════════════════════════════════════════
  //  GOFILE
  //  GoFile hämtar filinfo via API → vi fångar API-svaret och plockar ut
  //  den riktiga CDN-URL:en + Bearer-token innan browsern ens börjar ladda.
  // ══════════════════════════════════════════════════════════════════════════
  function setupGoFile() {
    const origFetch = window.fetch.bind(window);

    window.fetch = async function (input, init) {
      const url = typeof input === 'string' ? input : (input?.url ?? '');
      const resp = await origFetch(input, init);

      // Fånga GoFile content-API-svar
      if (/api\.gofile\.io\/contents\//i.test(url)) {
        try {
          const clone = resp.clone();
          const json  = await clone.json();

          if (json?.status === 'ok' && json?.data) {
            const token = getGoFileToken();
            const files = json.data.children
              ? Object.values(json.data.children).filter(f => f.type === 'file')
              : (json.data.type === 'file' ? [json.data] : []);

            files.forEach(file => {
              if (!file.link) return;
              chrome.runtime.sendMessage({
                type:     'CONTENT_DOWNLOAD',
                url:      file.link,
                filename: file.name || file.link.split('/').pop(),
                referrer: location.href,
                auth:     token ? `Bearer ${token}` : '',
              });
            });

            // Stoppa GoFiles egna download-hantering
            if (files.length > 0) return new Response('{}', { status: 200 });
          }
        } catch (_) {}
      }

      return resp;
    };

    // Patcha även XHR för äldre GoFile-kod
    const origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
      this._sdmUrl = url;
      return origOpen.call(this, method, url, ...rest);
    };

    const origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function (...args) {
      this.addEventListener('load', function () {
        if (!/api\.gofile\.io\/contents\//i.test(this._sdmUrl || '')) return;
        try {
          const json = JSON.parse(this.responseText);
          if (json?.status !== 'ok' || !json?.data) return;
          const token = getGoFileToken();
          const files = json.data.children
            ? Object.values(json.data.children).filter(f => f.type === 'file')
            : (json.data.type === 'file' ? [json.data] : []);

          files.forEach(file => {
            if (!file.link) return;
            chrome.runtime.sendMessage({
              type: 'CONTENT_DOWNLOAD', url: file.link,
              filename: file.name || file.link.split('/').pop(),
              referrer: location.href,
              auth: token ? `Bearer ${token}` : '',
            });
          });
        } catch (_) {}
      });
      return origSend.apply(this, args);
    };
  }

  function getGoFileToken() {
    // GoFile sparar token i localStorage, inte cookies
    try { return localStorage.getItem('accountToken') || ''; } catch { return ''; }
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  BUZZHEAVIER
  //  BuzzHeavier triggar nedladdning via klick → vi fångar klicket,
  //  hindrar Chrome och skickar direkt till SDM.
  // ══════════════════════════════════════════════════════════════════════════
  function setupBuzzHeavier() {
    // 1. Klick-interceptor (capture phase = körs före sidans egna handlers)
    document.addEventListener('click', handleBuzzClick, true);

    // 2. Patcha window.open (BuzzHeavier kan öppna nytt fönster med fil-URL)
    const origOpen = window.open;
    window.open = function (url, ...args) {
      if (url && looksLikeFileUrl(url)) {
        interceptBuzz(url);
        return null;
      }
      return origOpen.call(window, url, ...args);
    };

    // 3. Övervaka dynamiskt tillagda <a download>-element
    const mo = new MutationObserver(mutations => {
      mutations.forEach(m => m.addedNodes.forEach(node => {
        if (node.nodeType !== 1) return;
        const links = node.matches?.('a[download]')
          ? [node]
          : [...(node.querySelectorAll?.('a[download]') || [])];
        links.forEach(a => {
          if (a._sdmPatched) return;
          a._sdmPatched = true;
          a.addEventListener('click', e => {
            if (!a.href || a.href.startsWith('javascript')) return;
            e.preventDefault();
            e.stopImmediatePropagation();
            interceptBuzz(a.href, a.download || '');
          }, true);
        });
      }));
    });
    mo.observe(document, { childList: true, subtree: true });
  }

  function handleBuzzClick(e) {
    const el = e.target.closest('a, button, [role="button"]');
    if (!el) return;

    const href = el.href || el.dataset.href || el.dataset.url || '';
    const text = (el.textContent || '').toLowerCase().trim();
    const isDownload =
      el.hasAttribute('download') ||
      el.dataset.action === 'download' ||
      text === 'download' ||
      text === 'ladda ner' ||
      text.startsWith('download ') ||
      (href && looksLikeFileUrl(href));

    if (!isDownload || !href || href.startsWith('javascript')) return;

    e.preventDefault();
    e.stopImmediatePropagation();
    interceptBuzz(href, el.download || '');
  }

  function interceptBuzz(url, suggestedName) {
    const filename = suggestedName
      || url.split('/').pop().split('?')[0]
      || 'fil';

    chrome.runtime.sendMessage({
      type: 'CONTENT_DOWNLOAD',
      url,
      filename,
      referrer: location.href,
      auth: '',
    }, resp => {
      // Om SDM offline – låt Chrome hantera det ändå
      if (!resp?.ok) window.location.href = url;
    });
  }

  function looksLikeFileUrl(url) {
    try {
      const p = new URL(url, location.href).pathname.toLowerCase();
      const ext = p.split('.').pop();
      const knownExts = new Set([
        'zip','rar','7z','tar','gz','exe','msi','iso','apk',
        'mp4','mkv','avi','mp3','flac','pdf','epub','torrent',
      ]);
      return knownExts.has(ext) || /\/(f|d|dl|file|download)\/[\w-]+/i.test(p);
    } catch { return false; }
  }
})();
